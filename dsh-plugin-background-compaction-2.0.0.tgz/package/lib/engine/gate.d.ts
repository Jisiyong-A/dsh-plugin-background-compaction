/**
 * Sliding-window hit-rate circuit breaker for background speculation.
 *
 * Each background precompute bets one LLM summarization call to save one blocking
 * foreground summarization call. Measuring shadowed tokens is misleading because the
 * foreground path reclaims shadowed tokens too — the true economic unit is whether the
 * speculative call was actually consumed (hit) or discarded (miss).
 *
 * When the last `windowSize` settled speculations fall below `minHitRate`, the gate
 * pauses new speculations for `cooldownMs`. Once the cooldown elapses, the window is
 * cleared so the engine gets a clean recovery trial.
 */
/** Immutable snapshot of observed outcomes and circuit-breaker state. */
export interface SpeculationStats {
    /** Total precomputed summaries committed by a real compaction. */
    hits: number;
    /** Total precomputed summaries that expired, were superseded, failed, or mismatched. */
    misses: number;
    /** Hits inside the current sliding window. */
    windowHits: number;
    /** Outcomes currently inside the sliding window (`0..options.windowSize`). */
    windowSize: number;
    /** Hit rate across the current sliding window (`1` when empty). */
    hitRate: number;
    /** Epoch millis until which speculation is paused (`0` when open). */
    pausedUntil: number;
}
/** Tunables for {@link SpeculationGate}. */
export interface SpeculationGateOptions {
    /** Enable the circuit breaker; when false speculation is always allowed. */
    enabled: boolean;
    /** Number of recent outcomes evaluated before the breaker can trip. */
    windowSize: number;
    /** Minimum hit rate in `[0, 1]` over `windowSize` required to stay open. */
    minHitRate: number;
    /** Duration (ms) to pause speculation when the window drops below `minHitRate`. */
    cooldownMs: number;
}
/** Sliding-window circuit breaker guarding speculative background calls. */
export declare class SpeculationGate {
    private readonly options;
    private hits;
    private misses;
    private readonly recent;
    private pausedUntil;
    constructor(options: SpeculationGateOptions);
    /** Book a precomputed summary that a real compaction committed. */
    recordHit(now?: number): void;
    /** Book a speculative attempt that did not get committed. */
    recordMiss(now?: number): void;
    /** Decide whether a new speculative summarization is allowed at `now`. */
    shouldSpeculate(now?: number): boolean;
    /** Snapshot of cumulative counters and current window state. */
    stats(): SpeculationStats;
    /** Reset all observations and reopen the breaker. */
    reset(): void;
    private pushOutcome;
    private countWindowHits;
    private currentWindowHitRate;
}
//# sourceMappingURL=gate.d.ts.map