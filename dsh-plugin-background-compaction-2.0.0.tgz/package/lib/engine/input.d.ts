/**
 * Summarization-input construction and fingerprinting.
 *
 * Mirrors `buildSummarizationInput` (`dsh-compaction-basic/lib/index.js:695-704`) and
 * hashes the exact payload plus the effective summarizer target (`provider`, `model`,
 * `maxTokens`) so any drift in messages, tools, or summarization model invalidates a
 * held entry cleanly.
 */
import type { SessionLike, SummarizationInput } from '@deepseek-ai/dsh-compaction-basic';
import type { SummarizerEnvelope } from './spec.js';
/**
 * Rebuild the summarizer payload for an explicit set of surface seqs.
 *
 * Mirrors `dsh-compaction-basic` verbatim so a fingerprint computed during background
 * precomputation matches the payload constructed by `compactRegion()` at commit time.
 */
export declare function buildSummarizationInput(session: SessionLike, shadowedSeqs: readonly number[]): SummarizationInput;
/**
 * Stable SHA-256 content hash of a summarizer payload and its target model envelope.
 */
export declare function fingerprintSummarizationInput(input: SummarizationInput, summarizer?: SummarizerEnvelope): string;
//# sourceMappingURL=input.d.ts.map