/**
 * Configuration split for the background-compaction engine.
 *
 * The subclass shares one config object with `BasicCompactionEngine`, which validates
 * its own keys against a strict allowlist (`BASIC_COMPACT_CONFIG_KEYS` in
 * `dsh-compaction-basic/lib/index.js:31-35, 59-60`) and throws on unknown keys.
 * Because Cordis schemastery validation is non-strict (`merge(result, data)`), this
 * plugin's extra keys reach the constructor untouched. {@link pickBaseConfig} forwards
 * only base-class keys verbatim to `super()`, and {@link resolveBackgroundConfig}
 * validates the plugin's own options.
 */
/** Options consumed by this plugin only; never forwarded to `BasicCompactionEngine`. */
export interface BackgroundCompactionOptions {
    /** Master switch. When false the engine behaves identically to `compaction-basic`. */
    enabled: boolean;
    /**
     * Fraction of the base engine's threshold at which background summarization starts.
     * Must be below 1 so the summary is ready before pressure triggers a foreground pass.
     */
    precomputeAtRatio: number;
    /** Skip speculation when the span being shadowed is worth fewer tokens than this. */
    minShadowTokens: number;
    /** Discard an unused held summary after this long (ms). */
    heldTtlMs: number;
    /** Coalescing window for pre-step precompute triggers (ms). */
    debounceMs: number;
    /** Maximum concurrent background summarization calls across all sessions. */
    maxConcurrent: number;
    /** Maximum number of sessions holding a summary at once. */
    maxSessions: number;
    /** Enable the sliding-window hit-rate circuit breaker. */
    gateEnabled: boolean;
    /** Number of recent settled speculations evaluated by the circuit breaker. */
    gateWindow: number;
    /** Minimum hit rate in `[0, 1]` over `gateWindow` required to keep speculating. */
    gateMinHitRate: number;
    /** Cooldown pause (ms) when recent hit rate drops below `gateMinHitRate`. */
    gateCooldownMs: number;
    /** Emit `[bgc]` diagnostic lines (via `ctx.logger` and stderr). */
    trace: boolean;
}
/** Defaults tuned for an interactive coding session. */
export declare const DEFAULT_BACKGROUND_CONFIG: Readonly<BackgroundCompactionOptions>;
/**
 * Strip this plugin's own keys so `BasicCompactionEngine.resolveConfig()` only sees
 * the allowlisted set it validates. Every present base key (including `headroomTokens: 0`,
 * which the base allows when `maxTokens` is positive) is forwarded verbatim.
 */
export declare function pickBaseConfig(config: Record<string, unknown> | undefined): Record<string, unknown>;
/** Read, validate and freeze this plugin's own options. */
export declare function resolveBackgroundConfig(config: Record<string, unknown> | undefined): Readonly<BackgroundCompactionOptions>;
//# sourceMappingURL=config.d.ts.map