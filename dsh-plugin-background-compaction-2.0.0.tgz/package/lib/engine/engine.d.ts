/**
 * Background-compaction engine.
 *
 * `BasicCompactionEngine` is DSH's sole `ctx.compaction` implementation per context
 * (`CompactionEngine extends Service`, constructor `super(ctx, 'compaction')`), so this
 * plugin replaces `compaction-basic` rather than running beside it. The subclass keeps
 * all of the framework's compaction invariants (span validation, durable
 * `compaction/start` + `compaction/end` markers, shrink check, `SurfaceChangedError`
 * guard, surface folding, tool-result pruning) and changes only when the summary text
 * is produced.
 *
 * While a conversation is between `precomputeAtRatio * thresholdTokens` and
 * `thresholdTokens`, a debounced background task pins the span the base engine would
 * select right now, summarizes those immutable surface seqs, and holds the result.
 * When pressure later crosses `thresholdTokens`, `compactIfNeeded` runs the optional
 * tool-result pruner, verifies the pinned span and payload+model fingerprint up front,
 * and commits that pinned span via `compactRegion()` with zero foreground LLM latency.
 * Any mismatch or rejection falls back cleanly to a single stock `super.compactIfNeeded()`
 * pass.
 */
import { BasicCompactionEngine } from '@deepseek-ai/dsh-compaction-basic';
import type { AgentLike, CompactionResult, SummarizationInput, SummaryResult } from '@deepseek-ai/dsh-compaction-basic';
import { type SpeculationStats } from './gate.js';
/**
 * `ctx.compaction` implementation that precomputes and serves held summaries.
 */
export declare class BackgroundCompactionEngine extends BasicCompactionEngine {
    private readonly background;
    private readonly traceActive;
    private readonly held;
    private readonly gate;
    private readonly guard;
    private readonly pending;
    private readonly running;
    private readonly committingHeld;
    private readonly directManaged;
    private readonly directServed;
    private cleanupListeners;
    private disposed;
    constructor(ctx: BasicCompactionEngine['ctx'], config?: Record<string, unknown>);
    /** Observed speculative outcomes; exposed for diagnostics and tests. */
    get speculationStats(): SpeculationStats;
    /** Number of live summaries currently held ready to serve. */
    get heldCount(): number;
    /**
     * Summarize a payload, serving a matching precomputed result when one exists.
     *
     * Every foreground compaction (`compactRegion`, `context-overflow`, manual `compactNow`)
     * enters here. Background precomputation calls `super.summarize()` directly and never
     * re-enters this method.
     */
    summarize(input: SummarizationInput, agent: AgentLike, signal?: AbortSignal): Promise<SummaryResult>;
    /**
     * Manual `/compact` entry point: cancels competing background work and defers hit/miss
     * booking until the base commit finishes.
     */
    compactNow(agent: AgentLike, signal: AbortSignal, sourceCommandId?: string): Promise<CompactionResult | null>;
    /**
     * Compact when pressure is reached, preferring a verified held summary's pinned span
     * and delegating cleanly to `BasicCompactionEngine` in every other case.
     */
    compactIfNeeded(agent: AgentLike, trigger: 'pressure' | 'context-overflow', signal?: AbortSignal): Promise<CompactionResult | null>;
    /**
     * Stop timers, cancel in-flight background calls, detach listeners, and clear the stash.
     *
     * Note: Cordis `Service` and `BasicCompactionEngine` do NOT define `dispose()`; automatic
     * lifecycle teardown runs via `ctx.effect()`, and this method is a safe idempotent
     * imperative entry point for callers and tests (must never call `super.dispose()`).
     */
    dispose(): void;
    /** Run a base foreground operation, booking a direct-path hit only once it commits. */
    private runDirectForeground;
    /** Bind the debounced speculation trigger for the lifetime of the owning Cordis fiber. */
    private bindSpeculation;
    /** Idempotent resource cleanup shared by fiber unload and `dispose()`. */
    private teardown;
    /** Sweep expired held summaries and record each as a miss. */
    private sweepExpired;
    /** Cancel any pending timer or in-flight background summarization for one session. */
    private cancelBackground;
    /** Drop every trace of a disposed session. */
    private forgetSession;
    /** True when `range` still sits intact and tool-pairing-balanced on `session.surface`. */
    private isHeldSpanIntact;
    /** True when `held`'s span, derived messages, tools, and summarizer envelope still match. */
    private matchesHeldPayload;
    /** Debounce a precompute pass for one agent. */
    private schedulePrecompute;
    /** Summarize the span the foreground engine would pick now, and hold the result. */
    private runPrecompute;
    /** Lazily format and emit one trace line when tracing is active. */
    private trace;
}
export default BackgroundCompactionEngine;
//# sourceMappingURL=engine.d.ts.map