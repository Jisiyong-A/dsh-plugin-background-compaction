/**
 * Anchored pressure math and summarizer-target resolution.
 *
 * Mirrors `resolveTargetPolicy()`, `resolveCompactSpec()`, `routedTarget()`, and
 * `summarizeWithLlm()` target selection in `dsh-compaction-basic/lib/index.js`
 * (lines 94-147, 293-303, 743-769, 899-903) so the plugin's watermark, retention
 * budget, and summary-cache fingerprint stay in exact lockstep with the base engine.
 */
import type { AgentLike, ModelInfo, ResolvedBasicConfig, SessionLike, TargetPolicy } from '@deepseek-ai/dsh-compaction-basic';
/** The provider/model pair durably routed for the latest request. */
export interface RoutedTarget {
    provider: string;
    model: string;
}
/** Concrete token budgets for one routed target. */
export interface CompactSpec {
    provider: string;
    model: string;
    contextWindow: number;
    /** Total estimated tokens at which the foreground engine compacts. */
    thresholdTokens: number;
    /** Minimum recent tail retained verbatim by a compaction. */
    retainTokens: number;
}
/** Effective LLM parameters `summarizeWithLlm` would use right now. */
export interface SummarizerEnvelope {
    provider: string;
    model: string;
    maxTokens: number;
}
/** Resolve the exact provider/model the latest request was routed to. */
export declare function routedTarget(session: SessionLike): RoutedTarget | null;
/**
 * Merge an exact-target `modelPolicies` override over the validated defaults, mirroring
 * `resolveTargetPolicy()` in `dsh-compaction-basic/lib/index.js:94-111`.
 */
export declare function resolveTargetPolicy(config: ResolvedBasicConfig, target: RoutedTarget): TargetPolicy;
/**
 * Resolve the effective summarizer model and `maxTokens` that `BasicCompactionEngine.summarize()`
 * will use for `agent`, so a model or policy switch invalidates any held summary.
 */
export declare function resolveSummarizerEnvelope(config: ResolvedBasicConfig, agent: AgentLike): SummarizerEnvelope;
/** Derive the pressure and retention budgets the foreground engine would use right now. */
export declare function resolveCompactSpec(config: ResolvedBasicConfig, target: RoutedTarget, info: ModelInfo, session: SessionLike): CompactSpec | null;
/** Resolve the live spec for an agent, asking the adapter for that target's capacity. */
export declare function resolveSpecForAgent(config: ResolvedBasicConfig, llm: {
    resolveModelInfo(provider: string, model: string, signal?: AbortSignal): Promise<ModelInfo>;
}, agent: AgentLike, signal?: AbortSignal): Promise<CompactSpec | null>;
//# sourceMappingURL=spec.d.ts.map