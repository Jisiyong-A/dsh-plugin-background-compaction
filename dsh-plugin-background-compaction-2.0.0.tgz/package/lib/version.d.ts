export declare const PLUGIN_NAME = "dsh-plugin-background-compaction";
export declare const PLUGIN_VERSION = "2.0.0";
//# sourceMappingURL=version.d.ts.map